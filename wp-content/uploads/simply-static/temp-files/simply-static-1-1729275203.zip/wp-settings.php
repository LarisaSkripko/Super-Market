<br>
<b>Fatal error</b>:  Uncaught Error: Undefined constant &quot;ABSPATH&quot; in /Applications/MAMP/htdocs/Super-Market/wp-settings.php:33
Stack trace:
#0 {main}
  thrown in <b>/Applications/MAMP/htdocs/Super-Market/wp-settings.php</b> on line <b>33</b><br>