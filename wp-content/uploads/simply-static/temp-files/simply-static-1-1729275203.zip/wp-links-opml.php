<?xml version="1.0"?>
<opml version="1.0">
	<head>
		<title>
		Ссылки сайта «Super Market»		</title>
		<dateCreated>Fri, 18 Oct 2024 18:13:31 GMT</dateCreated>
		<!-- generator="WordPress/6.6.2" -->
	</head>
	<body>
</body>
</opml>
